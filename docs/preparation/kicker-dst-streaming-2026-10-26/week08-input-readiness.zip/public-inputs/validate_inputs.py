"""Replay readiness checks from retained bytes; no network or model execution."""
import hashlib
import json
from datetime import datetime
from pathlib import Path
from extract_inputs import extract

ROOT = Path(__file__).resolve().parent

def iso(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))

def validate():
    report = json.loads((ROOT / 'football-input-readiness.json').read_text())
    cutoff = iso(report['proposed_waiver_cutoff'])
    errors = []
    game_receipts = {}
    for receipt in report['receipts']:
        path = ROOT / receipt['file']
        if hashlib.sha256(path.read_bytes()).hexdigest() != receipt['published_excerpt_sha256']:
            errors.append(dict(file=receipt['file'], reason='published_excerpt_hash_mismatch'))
        if not iso(receipt['requested_at']) <= iso(receipt['received_at']) <= cutoff:
            errors.append(dict(file=receipt['file'], reason='capture_clock_outside_cutoff'))
        if path.name.startswith('game-'):
            game_receipts[path.stem.removeprefix('game-')] = receipt
    for team, history in report['history'].items():
        if len(history['game_ids']) != 4 or len(set(history['game_ids'])) != 4:
            errors.append(dict(team=team, reason='incomplete_or_duplicate_lookback'))
    credited_pairs = 0
    for game_id, recorded in report['games'].items():
        receipt = game_receipts[game_id]
        data = json.loads((ROOT / receipt['file']).read_bytes())
        replay = extract(game_id, dict(status='observed', data=data, receipt=receipt))
        if replay != recorded:
            errors.append(dict(game_id=game_id, reason='extraction_replay_mismatch'))
        if replay['status'] != 'observed_final' or len(replay.get('teams', {})) != 2:
            errors.append(dict(game_id=game_id, reason='game_identity_or_finality'))
            continue
        a, b = list(replay['teams'])
        for team, opponent in [(a, b), (b, a)]:
            row = replay['teams'][team]
            for key in ['passing_attempts', 'sacks_suffered', 'defense_sacks_credited', 'field_goal_attempts', 'pat_attempts']:
                value = row[key]
                if value is None or value < 0:
                    errors.append(dict(game_id=game_id, team=team, reason='missing_or_negative', field=key))
            if row['defense_sacks_credited'] != replay['teams'][opponent]['sacks_suffered']:
                errors.append(dict(game_id=game_id, team=team, reason='sack_reconciliation'))
            credited_pairs += 1
    result = dict(status='passed' if not errors else 'failed',
                  scope='published statistical excerpts: structural replay and same-provider reconciliation only; no original-HTTP-byte authentication, admission, scoring or predictive validation',
                  source_files_checked=len(report['receipts']), game_responses=len(report['games']),
                  team_game_rows=credited_pairs, history_rows=sum(len(x['game_ids']) for x in report['history'].values()),
                  errors=errors)
    (ROOT / 'validation.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result))
    if errors:
        raise SystemExit(1)

if __name__ == '__main__':
    validate()
