"""Offline extraction from retained statistical excerpts; no network."""
import re
CONFIG={"native_aliases":{"AZ":"ARI","WSH":"WAS"}}

def ratio(value):
    if not isinstance(value, str) or not re.fullmatch('\\d+/\\d+', value):
        return None
    made, attempts = map(int, value.split('/'))
    return dict(made=made, attempts=attempts) if 0 <= made <= attempts else None

def count(value):
    if isinstance(value, str) and re.fullmatch('\\d+(?:\\.\\d+)?', value):
        return float(value)
    return None

def extract(game_id, result):
    if result['status'] != 'observed':
        return dict(game_id=game_id, status='unavailable', reason=result.get('reason'))
    data = result['data']
    header = data.get('header', {})
    competitions = header.get('competitions', [])
    comp = competitions[0] if competitions else {}
    season = header.get('season', {})
    if header.get('id') != game_id or season.get('year') != 2026 or comp.get('status', {}).get('type', {}).get('completed') is not True:
        return dict(game_id=game_id, status='unavailable', reason='identity_season_or_finality_mismatch')
    teams = {}
    for team in data.get('boxscore', {}).get('teams', []):
        native = team.get('team', {})
        abbr = CONFIG['native_aliases'].get(native.get('abbreviation'), native.get('abbreviation'))
        fields = {s['name']: s.get('displayValue') for s in team.get('statistics', [])}
        passing = ratio(fields.get('completionAttempts'))
        sacks_text = fields.get('sacksYardsLost')
        sacks_suffered = int(sacks_text.split('-')[0]) if isinstance(sacks_text, str) and re.fullmatch('\\d+-\\d+', sacks_text) else None
        teams[abbr] = dict(team_id=native.get('id'), passing_attempts=passing['attempts'] if passing else None, sacks_suffered=sacks_suffered, defense_sacks_credited=None, field_goal_attempts=None, pat_attempts=None, kickers=[])
    for group in data.get('boxscore', {}).get('players', []):
        native = group.get('team', {})
        abbr = CONFIG['native_aliases'].get(native.get('abbreviation'), native.get('abbreviation'))
        if abbr not in teams:
            continue
        for category in group.get('statistics', []):
            keys = category.get('keys', [])
            totals = dict(zip(keys, category.get('totals', [])))
            if category.get('name') == 'defensive':
                teams[abbr]['defense_sacks_credited'] = count(totals.get('sacks'))
            if category.get('name') == 'kicking':
                fg = ratio(totals.get('fieldGoalsMade/fieldGoalAttempts'))
                xp = ratio(totals.get('extraPointsMade/extraPointAttempts'))
                teams[abbr]['field_goal_attempts'] = fg['attempts'] if fg else None
                teams[abbr]['pat_attempts'] = xp['attempts'] if xp else None
                for athlete in category.get('athletes', []):
                    player = athlete.get('athlete', {})
                    stats = dict(zip(keys, athlete.get('stats', [])))
                    teams[abbr]['kickers'].append(dict(espn_id=player.get('id'), name=player.get('displayName'), field_goals=ratio(stats.get('fieldGoalsMade/fieldGoalAttempts')), pats=ratio(stats.get('extraPointsMade/extraPointAttempts'))))
    return dict(game_id=game_id, status='observed_final', start_time=comp.get('date'), event_end=None, finality_observed_at=result['receipt']['received_at'], source_ref=result['receipt']['file'], teams=teams)
