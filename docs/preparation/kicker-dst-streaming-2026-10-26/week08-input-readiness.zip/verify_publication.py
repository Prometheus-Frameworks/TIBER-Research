"""Check published packet integrity and forbidden unrelated content; offline."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'public-inputs'
FORBIDDEN = {'owner_id', 'co_owners', 'metadata', 'accountUserId', 'username',
             'email', 'starters', 'taxi', 'reserve', 'article', 'news', 'story',
             'videos', 'pickcenter', 'odds', 'winprobability'}

def walk(value):
    if isinstance(value, dict):
        assert not (set(value) & FORBIDDEN), f'Forbidden keys: {set(value) & FORBIDDEN}'
        assert not any(k.startswith('p_nick_') for k in value), 'Nickname metadata'
        for item in value.values(): walk(item)
    elif isinstance(value, list):
        for item in value: walk(item)

if __name__ == '__main__':
    manifest = json.loads((ROOT/'MANIFEST.json').read_text())
    paths = [r['path'] for r in manifest['files']]
    assert len(paths) == len(set(paths)), 'Duplicate manifest path'
    for row in manifest['files']:
        p = (ROOT/row['path']).resolve()
        assert p.is_relative_to(ROOT.resolve()), 'Path escape'
        body = p.read_bytes()
        assert len(body) == row['size'], f'Size mismatch: {p.name}'
        assert hashlib.sha256(body).hexdigest() == row['sha256'], f'Hash mismatch: {p.name}'
        if p.suffix == '.json': walk(json.loads(body))
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*')
              if p.is_file() and '__pycache__' not in p.parts and p.name != 'MANIFEST.json'}
    assert actual == set(paths), 'Manifest coverage differs from published files'
    print(f'PASS: {len(paths)} manifest entries; unrelated member metadata and publisher prose fields absent')
